#takes:
# - armor.ini
# - armor.inc

with open("armor.ini", "r") as infile:
    armors_ini = [x for x in infile.read().split("\n") if not x.startswith(("#", ";"))]

with open("armor.inc", "r") as infile:
    armors_inc = [x for x in infile.read().split("\n") if not x.startswith(("#", ";"))]

armors_raw = armors_ini + armors_inc

f = open("armor.txt", "a")

armors = {}
armor = None
for line in armors_raw:
    if line.startswith("Armor") and "=" not in line:
        armor = line.split(" ")[1]
        armors[armor] = {}
    elif "Armor" in line and "=" in line:
        info = line.split("=")[1]
        if ";" in info:
            info = info[:info.index(";")-1]

        try:
            damage_type, damage_num = [x for x in info.split(" ") if x]
        except Exception as e:
            print([x for x in info.split(" ") if x])
            raise e

        armors[armor][damage_type] = damage_num

sorted_armor = sorted(armors.keys())
f.write("<tabber>")
previous_letter = ""

for armor in sorted_armor:
    if armor[0] != previous_letter:
        f.write("|-|"+armor[0]+"=")
    
    previous_letter = armor[0]    
    f.write('{| class="wikitable"\n')
    f.write(f'! colspan="2" |  <span class="mw-customtoggle-{armor} wikia-menu-button" style="float:left">[+/-]</span>{armor}\n')
    f.write(f'|- id="mw-customcollapsible-{armor}" class="mw-collapsible mw-collapsed"\n')
    f.write('!Damage Type !! Percentage\n')
    for damage_type in armors[armor]:
        f.write(f'|- id="mw-customcollapsible-{armor}" class="mw-collapsible mw-collapsed"\n')
        f.write(f'| {damage_type} || {armors[armor][damage_type]}\n')        
    f.write("|}\n")
    f.write("\n")

f.write("</tabber>")
f.close()
    